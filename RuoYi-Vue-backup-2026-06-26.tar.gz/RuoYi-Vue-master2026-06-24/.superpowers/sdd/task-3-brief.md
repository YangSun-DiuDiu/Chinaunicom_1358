### Task 3: 前端 — 审批页 + 预约页改造 + 管理页修复

- Create: `ruoyi-ui/src/views/meeting/approval/index.vue`
- Modify: `ruoyi-ui/src/views/meeting/booking/index.vue`
- Modify: `ruoyi-ui/src/views/meeting/manage/index.vue`
- Modify: `ruoyi-ui/src/router/index.js` (添加 approval 路由)

**审批页** (`approval/index.vue`):
- 列表默认 `status=PENDING`，按 start_time 升序
- 表格：title, roomName, hostName, startTime, endTime, attendees, status
- 操作：通过(PUT /approve)、拒绝(PUT /reject)

**预约页** (`booking/index.vue`):
- 列表自动加 `my=1` 过滤当前用户
- 新建弹窗选会议室后自动加载 slots
- 时间轴显示已占用时段（色块），点击空闲区域选时间

**管理页** (`manage/index.vue`):
- 默认不限制 status
- 增加日期选择器 + 会议室筛选

**路由**：添加 `/meeting/approval` 到 `staticRoutes`

- [ ] `npm run build:prod` → DONE
- [ ] `git add -A && git commit -m "feat: split approval page, add timeline, fix manage data"`

---

