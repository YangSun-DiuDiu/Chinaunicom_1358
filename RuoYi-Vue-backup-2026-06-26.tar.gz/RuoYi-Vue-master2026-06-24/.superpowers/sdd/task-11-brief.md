### Task 11: 创建 DeptFillAspect — 写入自动填充

**Files:**
- Create: `ruoyi-framework/src/main/java/com/ruoyi/framework/aspectj/DeptFillAspect.java`

**Interfaces:**
- Consumes: `BaseEntity.deptId`, `SecurityUtils.getDeptId()`
- Produces: AOP aspect that auto-fills `deptId` on add/edit controller methods

- [ ] **Step 1: 创建 DeptFillAspect.java**

```java
// file: ruoyi-framework/src/main/java/com/ruoyi/framework/aspectj/DeptFillAspect.java
package com.ruoyi.framework.aspectj;

import com.ruoyi.common.core.domain.BaseEntity;
import com.ruoyi.common.utils.SecurityUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * AOP 切面：自动为新增/修改的实体填充 dept_id（所属组织）
 * 
 * 拦截 Controller 层 add/edit/save/insert/update 方法
 * 对于继承 BaseEntity 的入参，自动设置 deptId
 */
@Aspect
@Component
public class DeptFillAspect {

    private static final Logger log = LoggerFactory.getLogger(DeptFillAspect.class);

    @Before("execution(* com.ruoyi.web.controller..*.add*(..)) || " +
            "execution(* com.ruoyi.web.controller..*.edit*(..)) || " +
            "execution(* com.ruoyi.web.controller..*.save*(..)) || " +
            "execution(* com.ruoyi.web.controller..*.insert*(..)) || " +
            "execution(* com.ruoyi.web.controller..*.update*(..))")
    public void fillDeptId(JoinPoint joinPoint) {
        try {
            Object[] args = joinPoint.getArgs();
            if (args == null || args.length == 0) {
                return;
            }

            Long currentDeptId = SecurityUtils.getDeptId();
            if (currentDeptId == null) {
                return;
            }

            for (Object arg : args) {
                if (arg instanceof BaseEntity) {
                    BaseEntity entity = (BaseEntity) arg;
                    if (entity.getDeptId() == null) {
                        entity.setDeptId(currentDeptId);
                        log.debug("DeptFillAspect: auto-filled deptId={} for {}", currentDeptId, arg.getClass().getSimpleName());
                    }
                }
            }
        } catch (Exception e) {
            log.warn("DeptFillAspect: failed to fill deptId", e);
        }
    }
}
```

- [ ] **Step 2: Commit**

```bash
git add -A && git commit -m "feat: add DeptFillAspect for automatic dept_id write fill"
```

---

