### Task 5: 构建部署验证

- [ ] **构建**: `mvn clean package -DskipTests -q && cd ruoyi-ui && npm run build:prod`
- [ ] **部署**: scp jar + dist to server, restart
- [ ] **验证**: 后端 8090 → 200, 前端 80 → 200, slots API, 审批页加载
- [ ] **Commit**: `chore: deploy meeting booking improvements` + push
