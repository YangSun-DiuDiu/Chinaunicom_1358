### Task 1: 数据库菜单 + 权限调整

- [ ] **Step 1: 删除旧会议预约菜单，新建预约和审批菜单**

```sql
DELETE FROM sys_role_menu WHERE menu_id=2033;
DELETE FROM sys_menu WHERE menu_id=2033;

INSERT INTO sys_menu (menu_name, parent_id, order_num, path, component, menu_type, visible, status, perms, create_by, create_time)
VALUES ('会议预约', 2031, 2, 'booking', 'meeting/booking/index', 'C', '0', '0', 'meeting:booking:list', 'admin', NOW());
SET @booking_id = LAST_INSERT_ID();

INSERT INTO sys_menu (menu_name, parent_id, order_num, path, component, menu_type, visible, status, perms, create_by, create_time)
VALUES ('会议审批', 2031, 3, 'approval', 'meeting/approval/index', 'C', '0', '0', 'meeting:approval:list', 'admin', NOW());
SET @approval_id = LAST_INSERT_ID();

INSERT INTO sys_role_menu (role_id, menu_id) VALUES (1, @booking_id), (1, @approval_id);
```

- [ ] **Step 2: 执行 + 验证**

```bash
mysql -h 1.94.26.126 -P 3306 -u sadmin -pChinaunicom@1358 ry101 < sql/meeting_menu_fix.sql
mysql ... -e "SELECT menu_id, menu_name, perms FROM sys_menu WHERE parent_id=2031;"
```

- [ ] **Step 3: Commit**

```bash
git add -A && git commit -m "fix: split meeting booking and approval into separate menus with permissions"
```

---

