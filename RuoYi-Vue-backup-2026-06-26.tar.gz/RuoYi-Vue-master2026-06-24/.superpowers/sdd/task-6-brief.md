### Task 6: 后端白名单 + 路由 + 编译部署验证

**Files:**
- Modify: `ruoyi-framework/src/main/java/com/ruoyi/framework/config/SecurityConfig.java` (白名单加 `/meeting/board/**`)
- Modify: `ruoyi-framework/src/main/java/com/ruoyi/framework/config/properties/PermitAllUrlProperties.java` (如有 @Anonymous 则自动)

- [ ] **Step 1: 添加白名单**

在 `SecurityConfig.java` 的 `permitAll` 链中添加：
```java
.antMatchers("/meeting/board/**").permitAll()
```

- [ ] **Step 2: 全量构建**

```bash
cd <项目根> && mvn clean package -DskipTests -q && cd ruoyi-ui && npm run build:prod
```

- [ ] **Step 3: 部署**

```bash
scp ruoyi-admin/target/ruoyi-admin.jar root@1.94.26.126:/root/zhihuiyuanqu20260625/
scp -r ruoyi-ui/dist/* root@1.94.26.126:/usr/share/nginx/zhihuiyuanqu/dist/
ssh root@1.94.26.126 'cd /root/zhihuiyuanqu20260625 && bash stop-server.sh && bash start-server.sh && nginx -s reload'
```

- [ ] **Step 4: 验证**

```bash
# 后端
curl -s -o /dev/null -w "HTTP %{http_code}" http://1.94.26.126:8090/
# 前端
curl -s -o /dev/null -w "HTTP %{http_code}" http://1.94.26.126:80/
# 平板 API（无需登录）
curl -s http://1.94.26.126:8090/meeting/board/1 | head -c 200
# 预约冲突检测
TOKEN=$(登录获取)
curl -s -X POST http://1.94.26.126:8090/meeting/booking -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"roomId":1,"title":"测试","startTime":"2026-06-26 09:00","endTime":"2026-06-26 10:00"}'
```

- [ ] **Step 5: Commit & Push**

```bash
git add -A && git commit -m "chore: deploy meeting management feature" && git push origin master
```
