### Task 9: BaseEntity 新增 deptId 字段

**Files:**
- Modify: `ruoyi-common/src/main/java/com/ruoyi/common/core/domain/BaseEntity.java`
- Modify: `ruoyi-common/src/main/java/com/ruoyi/common/constant/CacheConstants.java`

**Interfaces:**
- Consumes: nothing new
- Produces: `BaseEntity.deptId` (Long), `CacheConstants.DEPT_CONTEXT_KEY`

- [ ] **Step 1: BaseEntity 新增 deptId**

In `BaseEntity.java`, after the `remark` field, add:

```java
/** 所属组织ID（多租户数据隔离） */
private Long deptId;

public Long getDeptId() {
    return deptId;
}

public void setDeptId(Long deptId) {
    this.deptId = deptId;
}
```

- [ ] **Step 2: CacheConstants 新增 DEPT_CONTEXT_KEY**

In `CacheConstants.java`, add:

```java
/** 管理员组织切换上下文 */
public static final String DEPT_CONTEXT_KEY = "dept_context:";
```

- [ ] **Step 3: Commit**

```bash
git add -A && git commit -m "feat: add deptId field to BaseEntity and DEPT_CONTEXT_KEY constant"
```

---

