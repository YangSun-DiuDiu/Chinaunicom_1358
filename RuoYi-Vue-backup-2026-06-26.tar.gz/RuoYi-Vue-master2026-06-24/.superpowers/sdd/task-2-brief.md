### Task 2: 后端 — slots 接口 + 预约过滤

- Modify: `ruoyi-admin/src/main/java/com/ruoyi/web/controller/meeting/MeetingBookingController.java`
- Modify: `ruoyi-system/src/main/resources/mapper/system/MeetingBookingMapper.xml`

**slots 接口**：
```java
@GetMapping("/slots/{roomId}")
public AjaxResult slots(@PathVariable Long roomId, @RequestParam String date) {
    List<MeetingBooking> list = bookingService.selectSlots(roomId, date);
    return success(list);
}
```

**Mapper** (新增 `selectSlots`)：
```xml
<select id="selectSlots" resultMap="MeetingBookingResult">
    SELECT * FROM meeting_booking
    WHERE room_id=#{roomId} AND DATE(start_time)=#{date}
    AND status IN ('PENDING','APPROVED')
    ORDER BY start_time
</select>
```

**预约列表过滤**：`selectList` 增加 `createBy` 参数（预约页传当前用户名）。

- [ ] **Step 1**: `mvn compile -pl ruoyi-admin -am -DskipTests` → BUILD SUCCESS
- [ ] **Step 2**: `git add -A && git commit -m "feat: add slots endpoint and booking my-filter"`

---

