### Task 2: slots endpoint + booking filter -- COMPLETED

**Commit**: `75711fa` - feat: add slots endpoint and booking my-filter

**Changes** (5 files):

| File | Change |
|------|--------|
| `MeetingBookingMapper.java` | Added `selectSlots(roomId, date)` method |
| `MeetingBookingMapper.xml` | Added `selectSlots` query (roomId + date + status IN PENDING/APPROVED); Added `createBy` filter to `selectMeetingBookingList` |
| `IMeetingBookingService.java` | Added `selectSlots(Long roomId, String date)` to interface |
| `MeetingBookingServiceImpl.java` | Added `selectSlots` implementation delegating to mapper |
| `MeetingBookingController.java` | Added `GET /meeting/booking/slots/{roomId}?date=` endpoint returning `AjaxResult` |

**Verification**:
- `mvn compile -pl ruoyi-admin -am -DskipTests` -> BUILD SUCCESS
- All modules compiled: ruoyi, ruoyi-common, ruoyi-system, ruoyi-framework, ruoyi-quartz, ruoyi-admin
