# Fix Report — CRITICAL and HIGH Review Findings

**Date:** 2026-06-25
**Build:** `mvn clean compile -DskipTests` — BUILD SUCCESS (18.2s, 6/6 modules)

## Changes Applied

### C1: Add @Component to DeptScopeInterceptor
- **File:** `ruoyi-framework/src/main/java/com/ruoyi/framework/interceptor/DeptScopeInterceptor.java`
- **Change:** Added `@Component` annotation and `import org.springframework.stereotype.Component;`
- **Reason:** Without `@Component`, Spring would not auto-detect this MyBatis interceptor plugin, making it inactive.

### C2a-h: Add dept_id to INSERT statements (8 Mapper XMLs)
Added `<if test="deptId != null">dept_id,</if>` to INSERT column lists and `<if test="deptId != null">#{deptId},</if>` to VALUES lists:

| File | INSERT ID |
|------|-----------|
| `DeviceMapper.xml` | insertDevice |
| `DeviceRepairMapper.xml` | insertRepair |
| `DevicePortMapper.xml` | insertPort |
| `DeviceHeartbeatLogMapper.xml` | insertLog |
| `DeviceStatusLogMapper.xml` | insertLog |
| `VisitorAppointmentMapper.xml` | insertAppointment |
| `VisitorLogMapper.xml` | insertLog |
| `SmsLogMapper.xml` | insertSmsLog |

### C3: Add /treeselect endpoint to SysDeptController
- **File:** `ruoyi-admin/src/main/java/com/ruoyi/web/controller/system/SysDeptController.java`
- **Change:** Added `treeselect()` method with `@PreAuthorize("@ss.hasRole('admin')")` and `@GetMapping("/treeselect")`
- **Fix:** Used `selectDeptList()` (returns `List<SysDept>`) + `buildDeptTreeSelect()` instead of `selectDeptTreeList()` which returns `List<TreeSelect>` directly.

### H4a-h: Add dept_id to SELECT fragments (8 Mapper XMLs)
Added `dept_id` column to the selectVo SQL fragment and inline SELECT queries:

| File | Alias | Change |
|------|-------|--------|
| `DeviceMapper.xml` | d | `d.dept_id,` after `d.device_id,` in selectDeviceVo + inline SELECT |
| `DeviceRepairMapper.xml` | (none -> r) | `r.dept_id,` at start of selectRepairVo |
| `DevicePortMapper.xml` | p | `p.dept_id,` after `p.port_id,` in selectDevicePortVo + inline SELECT |
| `DeviceHeartbeatLogMapper.xml` | l | `l.dept_id,` after `l.log_id,` in selectVo + inline SELECT |
| `DeviceStatusLogMapper.xml` | l | `l.dept_id,` after `l.log_id,` in selectVo + inline SELECT |
| `VisitorAppointmentMapper.xml` | a | `a.dept_id,` after `a.appointment_id,` in selectVo |
| `VisitorLogMapper.xml` | l | `l.dept_id,` after `l.log_id,` in selectVo |
| `SmsLogMapper.xml` | (none) | `dept_id,` after `sms_id,` in selectVo |

### H5: Add role check to DeptScopeInterceptor admin bypass
- **File:** `ruoyi-framework/src/main/java/com/ruoyi/framework/interceptor/DeptScopeInterceptor.java`
- **Change:** `SecurityUtils.isAdmin()` changed to `SecurityUtils.isAdmin() || SecurityUtils.hasRole("admin")`
- **Reason:** Users with the "admin" role but not user ID 1 should also bypass dept filtering.

### H6: Add Redis context check to DeptFillAspect
- **File:** `ruoyi-framework/src/main/java/com/ruoyi/framework/aspectj/DeptFillAspect.java`
- **Change:** 
  - Replaced `SecurityUtils.getDeptId()` with `getCurrentDeptId()` private method
  - New method checks Redis `DEPT_CONTEXT_KEY` first (for admin-switched context), falls back to `SecurityUtils.getDeptId()`
  - Added imports: `CacheConstants`, `RedisCache`, `SpringUtils`

## Verification

```
mvn clean compile -DskipTests
```
- ruoyi: SUCCESS
- ruoyi-common: SUCCESS
- ruoyi-system: SUCCESS
- ruoyi-framework: SUCCESS
- ruoyi-quartz: SUCCESS
- ruoyi-admin: SUCCESS
- **0 errors**, only pre-existing deprecation warnings
