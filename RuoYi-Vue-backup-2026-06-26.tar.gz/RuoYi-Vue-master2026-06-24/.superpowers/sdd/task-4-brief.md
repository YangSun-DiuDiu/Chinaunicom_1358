### Task 4: 前端 — 会议室管理加平板地址列

- Modify: `ruoyi-ui/src/views/meeting/room/index.vue`

表格新增列：
```html
<el-table-column label="平板地址" min-width="300">
  <template slot-scope="{row}">
    <el-input :value="'http://1.94.26.126:80/meeting/board?roomId='+row.roomId" size="mini" readonly style="width:240px"/>
    <el-button size="mini" icon="el-icon-document-copy" style="margin-left:4px" @click="copyBoardUrl(row)">复制</el-button>
  </template>
</el-table-column>
```
方法：
```javascript
copyBoardUrl(row) {
  const url = 'http://1.94.26.126:80/meeting/board?roomId=' + row.roomId
  navigator.clipboard.writeText(url).then(() => this.$message.success('已复制'))
}
```

- [ ] `npm run build:prod` → DONE
- [ ] `git add -A && git commit -m "feat: add board URL column to meeting room table"`

---

