### Task 7: 前端 CrudTable 通用表格组件

**Files:**
- Create: `ruoyi-ui/src/components/CrudTable/index.vue`

**Interfaces:**
- Consumes: Element UI el-table, Pagination component
- Produces: `<CrudTable>` with props: columns, data, total, loading, selection

- [ ] **Step 1: 创建 CrudTable/index.vue**

```vue
<!-- file: ruoyi-ui/src/components/CrudTable/index.vue -->
<template>
  <div class="crud-table">
    <el-table
      v-loading="loading"
      :data="data"
      @selection-change="handleSelectionChange"
      border
      stripe
    >
      <el-table-column v-if="selection" type="selection" width="55" align="center" />
      <template v-for="col in columns">
        <el-table-column
          :key="col.prop"
          :label="col.label"
          :prop="col.prop"
          :width="col.width"
          :align="col.align || 'center'"
          :sortable="col.sortable"
          :formatter="col.formatter"
        >
          <template v-if="col.slot" v-slot="scope">
            <slot :name="col.slot" :row="scope.row" :index="scope.$index" />
          </template>
        </el-table-column>
      </template>
    </el-table>
    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />
  </div>
</template>

<script>
export default {
  name: 'CrudTable',
  props: {
    columns: { type: Array, required: true },
    data: { type: Array, default: () => [] },
    total: { type: Number, default: 0 },
    loading: { type: Boolean, default: false },
    queryParams: { type: Object, default: () => ({}) },
    selection: { type: Boolean, default: true }
  },
  methods: {
    handleSelectionChange(selection) {
      this.$emit('selection-change', selection)
    },
    getList() {
      this.$emit('get-list')
    }
  }
}
</script>
```

- [ ] **Step 2: 在 main.js 中全局注册 CrudTable**

Modify `ruoyi-ui/src/main.js` — after existing global component registrations, add:

```javascript
import CrudTable from '@/components/CrudTable'
Vue.component('CrudTable', CrudTable)
```

- [ ] **Step 3: Commit**

```bash
git add -A && git commit -m "feat: add CrudTable reusable table component"
```

---

