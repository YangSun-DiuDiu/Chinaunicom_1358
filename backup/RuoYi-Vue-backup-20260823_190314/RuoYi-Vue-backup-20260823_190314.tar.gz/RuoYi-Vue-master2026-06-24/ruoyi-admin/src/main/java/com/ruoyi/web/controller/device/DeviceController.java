package com.ruoyi.web.controller.device;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.domain.entity.SysDept;
import com.ruoyi.system.domain.Device;
import com.ruoyi.system.service.IDeviceService;
import com.ruoyi.system.service.ISysDeptService;
import com.ruoyi.system.sms.SmsUtil;

/**
 * 设备管理
 *
 * @author ruoyi
 */
@RestController
@RequestMapping("/device")
public class DeviceController extends BaseController
{
    @Autowired
    private IDeviceService deviceService;

    @Autowired
    private SmsUtil smsUtil;

    @Autowired
    private ISysDeptService deptService;

    /**
     * 获取设备列表（支持部门过滤）
     */
    @PreAuthorize("@ss.hasPermi('device:list')")
    @GetMapping("/list")
    public TableDataInfo list(Device device)
    {
        startPage();
        List<Device> list = deviceService.selectDeviceList(device);
        return getDataTable(list);
    }

    /**
     * 查询部门树结构（供设备管理页组织架构树使用）
     */
    @PreAuthorize("@ss.hasPermi('device:list')")
    @GetMapping("/deptTree")
    public AjaxResult deptTree(SysDept dept)
    {
        return success(deptService.selectDeptTreeList(dept));
    }

    /**
     * 获取在线设备数量
     */
    @PreAuthorize("@ss.hasPermi('device:query')")
    @GetMapping("/onlineCount")
    public AjaxResult onlineCount()
    {
        return success(deviceService.selectOnlineCount());
    }

    /**
     * 获取离线设备数量
     */
    @PreAuthorize("@ss.hasPermi('device:query')")
    @GetMapping("/offlineCount")
    public AjaxResult offlineCount()
    {
        return success(deviceService.selectOfflineCount());
    }

    /**
     * 获取设备类型统计
     */
    @PreAuthorize("@ss.hasPermi('device:query')")
    @GetMapping("/deviceTypeStats")
    public AjaxResult deviceTypeStats()
    {
        return success(deviceService.selectDeviceTypeStats());
    }

    /**
     * 根据设备编号获取详细信息
     */
    @PreAuthorize("@ss.hasPermi('device:query')")
    @GetMapping(value = "/{deviceId}")
    public AjaxResult getInfo(@PathVariable Long deviceId)
    {
        return success(deviceService.selectDeviceById(deviceId));
    }

    /**
     * 新增设备
     */
    @PreAuthorize("@ss.hasPermi('device:add')")
    @Log(title = "设备管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody Device device)
    {
        device.setCreateBy(getUsername());
        return toAjax(deviceService.insertDevice(device));
    }

    /**
     * 修改设备
     */
    @PreAuthorize("@ss.hasPermi('device:edit')")
    @Log(title = "设备管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody Device device)
    {
        device.setUpdateBy(getUsername());
        return toAjax(deviceService.updateDevice(device));
    }

    /**
     * 删除设备
     */
    @PreAuthorize("@ss.hasPermi('device:remove')")
    @Log(title = "设备管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deviceIds}")
    public AjaxResult remove(@PathVariable Long[] deviceIds)
    {
        return toAjax(deviceService.deleteDeviceByIds(deviceIds));
    }

    /**
     * 导出设备
     */
    @PreAuthorize("@ss.hasPermi('device:export')")
    @Log(title = "设备管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Device device)
    {
        List<Device> list = deviceService.selectDeviceList(device);
        ExcelUtil<Device> util = new ExcelUtil<Device>(Device.class);
        util.exportExcel(response, list, "设备数据");
    }

    /**
     * 报修-发送短信
     */
    @PreAuthorize("@ss.hasPermi('device:repair')")
    @Log(title = "设备管理", businessType = BusinessType.OTHER)
    @PostMapping("/repair/{deviceId}")
    public AjaxResult repair(@PathVariable Long deviceId)
    {
        Device device = deviceService.selectDeviceById(deviceId);
        if (StringUtils.isNull(device))
        {
            return error("设备不存在");
        }
        if (StringUtils.isEmpty(device.getResponsiblePhone()))
        {
            return error("设备负责人电话为空，无法发送维修短信");
        }
        smsUtil.sendSms("device_repair_alert", device.getResponsiblePhone(),
            "{\"device_name\":\"" + device.getDeviceName() + "\"}", 1, null);
        return success();
    }

    /**
     * 获取设备拓扑树
     */
    @PreAuthorize("@ss.hasPermi('device:topology:query')")
    @GetMapping("/topology")
    public AjaxResult topology()
    {
        List<Device> allDevices = deviceService.selectDeviceList(new Device());
        // 只展示参与拓扑关联的设备：配置了父节点 或 被其他设备引用为父节点，隐藏完全孤立的设备
        Set<Long> parentIds = allDevices.stream()
            .map(Device::getParentId)
            .filter(Objects::nonNull)
            .collect(Collectors.toSet());
        List<Device> relatedDevices = allDevices.stream()
            .filter(d -> d.getParentId() != null || parentIds.contains(d.getDeviceId()))
            .collect(Collectors.toList());
        List<Map<String, Object>> tree = buildTopologyTree(relatedDevices, 0L);
        return success(tree);
    }

    /**
     * 递归构建设备拓扑树结构
     *
     * @param devices  所有设备列表
     * @param parentId 父设备ID
     * @return 拓扑树节点列表
     */
    private List<Map<String, Object>> buildTopologyTree(List<Device> devices, Long parentId)
    {
        List<Map<String, Object>> tree = new ArrayList<>();
        // 可见设备ID集合：父设备不在集合中（如被部门数据隔离过滤）时，将该设备提升为根节点展示，避免图块丢失
        Set<Long> visibleIds = devices.stream().map(Device::getDeviceId).collect(Collectors.toSet());
        for (Device device : devices)
        {
            Long deviceParentId = device.getParentId() == null ? 0L : device.getParentId();
            // 父设备不可见（跨部门父子关系），视为根节点挂载
            if (deviceParentId != 0L && !visibleIds.contains(deviceParentId))
            {
                deviceParentId = 0L;
            }
            if (deviceParentId.equals(parentId))
            {
                Map<String, Object> node = new HashMap<>();
                node.put("deviceId", device.getDeviceId());
                node.put("deviceName", device.getDeviceName());
                node.put("deviceType", device.getDeviceType());
                node.put("status", device.getStatus());
                node.put("ipAddress", device.getIpAddress());
                node.put("model", device.getModel());
                node.put("location", device.getLocation());
                node.put("responsible", device.getResponsible());
                node.put("remark", device.getRemark());
                node.put("icon", device.getIcon());
                node.put("cableType", device.getCableType());
                node.put("parentId", device.getParentId());
                List<Map<String, Object>> children = buildTopologyTree(devices, device.getDeviceId());
                node.put("children", children);
                tree.add(node);
            }
        }
        return tree;
    }
}
